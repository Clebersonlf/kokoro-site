Nesta pasta vive o front do Financeiro (quando você quiser colocar um painel).
Por ora, use as APIs:
/api/financeiro/saldo-professor
/api/financeiro/extrato-professor
/api/financeiro/payouts
