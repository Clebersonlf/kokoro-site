# kokoro-plataforma
Plataforma de ensino KOKORO
