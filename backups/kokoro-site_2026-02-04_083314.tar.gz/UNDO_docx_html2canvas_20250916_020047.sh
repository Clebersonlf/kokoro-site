#!/usr/bin/env bash
set -euo pipefail
mv -f "admin/financeiro/relatorios.html.bak.20250916_020047" "admin/financeiro/relatorios.html"
echo "Restaurado: admin/financeiro/relatorios.html"
