#!/usr/bin/env bash
set -euo pipefail

TS="$(date +%Y%m%d_%H%M%S)"
BASE="admin/financeiro"
SRC="$BASE/repasses.html"
FIN="$BASE/financeiro.html"
UNDO="UNDO_add_repasses_${TS}.sh"

mkdir -p "$BASE"

# ========= UNDO =========
cat > "$UNDO" <<EOF
#!/usr/bin/env bash
set -euo pipefail
echo ">> Restaurando alterações do patch 'Repasses (Colaboradores)'..."
# remover a página criada
[ -f "$SRC" ] && rm -f "$SRC" && echo " - removido: $SRC"
# restaurar financeiro.html se backup existir
if [ -f "$FIN.bak.$TS" ]; then
  mv -f "$FIN.bak.$TS" "$FIN"
  echo " - restaurado: $FIN"
fi
echo "OK: desfazido."
EOF
chmod +x "$UNDO"
echo ">> UNDO criado: ./$UNDO"

# ========= 1) Criar página repasses.html =========
cat > "$SRC" <<'HTML'
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>KOKORO 心 - Repasses (Colaboradores)</title>
  <style>
    :root{
      --bg:#0f1115; --card:#141821; --bord:#233043;
      --txt:#e6edf3; --muted:#9fb3c8; --blue:#3b82f6; --green:#22c55e; --amber:#f59e0b; --rose:#f43f5e; --vio:#8b5cf6;
    }
    *{box-sizing:border-box}
    body{margin:0; font-family:system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Arial; background:var(--bg); color:var(--txt); padding:24px}
    .container{max-width:1100px; margin:auto}
    h1{margin:0 0 16px; color:#93c5fd}
    .topbar{display:flex; justify-content:space-between; gap:12px; margin-bottom:16px}
    .btn{border:1px solid #2a3a55; background:#0f172a; color:#cfe4ff; padding:10px 14px; border-radius:8px; text-decoration:none; display:inline-flex; align-items:center; gap:8px; cursor:pointer}
    .btn:hover{border-color:#3b82f6}
    .card{background:linear-gradient(180deg,var(--card),#121725); border:1px solid var(--bord); border-radius:12px; padding:18px; margin:12px 0; box-shadow:0 10px 24px rgba(0,0,0,.25)}
    .grid{display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:14px}
    label{font-size:12px; color:var(--muted)}
    input,select,textarea{width:100%; padding:10px 12px; border:1px solid #2a3a55; border-radius:8px; background:#0f172a; color:#e6edf3; outline:none}
    input:focus,select:focus,textarea:focus{border-color:var(--blue); box-shadow:0 0 0 3px rgba(59,130,246,.15)}
    .actions{display:flex; gap:10px; flex-wrap:wrap; margin-top:10px}
    .primary{background:var(--blue); color:#fff; border:none}
    .good{background:var(--green); color:#001107; border:none}
    .wa{background:var(--vio); color:#fff; border:none}
    .danger{background:var(--rose); color:#fff; border:none}
    .muted{font-size:12px; color:var(--muted)}
    .row{display:flex; gap:10px; align-items:center; flex-wrap:wrap}
    .badge{display:inline-flex; align-items:center; gap:6px; font-weight:700; border-radius:999px; padding:6px 10px; font-size:12px; background:#0b1320; border:1px solid #2a3a55; color:#cfe4ff}
    .preview{min-height:160px}
  </style>
</head>
<body>
  <div class="container">
    <div class="topbar">
      <a class="btn" href="/admin/index.html">← Voltar ao Admin</a>
      <a class="btn" href="/admin/financeiro/financeiro.html">Finanças</a>
    </div>

    <h1>Repasses (Colaboradores)</h1>

    <div class="card">
      <div class="grid">
        <div>
          <label>Admin Secret (salvo localmente)</label>
          <input id="admin-secret" type="password" placeholder="cole aqui seu x-admin-secret"/>
          <div class="muted">Fica salvo só neste navegador (localStorage).</div>
        </div>
        <div>
          <label>Professor (ID)</label>
          <input id="prof-id" placeholder="ex.: uuid do professor"/>
        </div>
        <div>
          <label>Nome (só para referência visual)</label>
          <input id="prof-nome" placeholder="opcional; não vai para o servidor"/>
        </div>
        <div>
          <label>Faixa</label>
          <input id="faixa" placeholder='ex.: "preta", "preta 3º", "marrom", "roxa", "azul"'/>
        </div>
        <div>
          <label>É Titular?</label>
          <select id="eh-titular">
            <option value="nao">Não</option>
            <option value="sim">Sim</option>
          </select>
        </div>
        <div>
          <label>Método</label>
          <select id="metodo">
            <option>PIX</option>
            <option>Dinheiro</option>
            <option>Cartão</option>
            <option>Transferência</option>
          </select>
        </div>
        <div>
          <label>Valor (R$)</label>
          <input id="valor" type="number" step="0.01" placeholder="0,00"/>
        </div>
        <div>
          <label>Pago em (data/hora)</label>
          <input id="pago-em" type="datetime-local"/>
        </div>
        <div>
          <label>Enviar E-mail para</label>
          <input id="email" type="email" placeholder="ex.: nome@dominio.com"/>
        </div>
        <div>
          <label>Enviar WhatsApp para</label>
          <input id="whats" placeholder="ex.: +55DDDNUMERO"/>
        </div>
      </div>

      <div class="actions">
        <button class="btn primary" id="btn-preview">Pré-visualizar</button>
        <button class="btn good" id="btn-email">Enviar por E-mail</button>
        <button class="btn wa" id="btn-wa">Enviar por WhatsApp</button>
        <button class="btn danger" id="btn-limpar">Limpar</button>
        <span class="badge" id="calc-badge">Título: —</span>
      </div>
      <div style="margin-top:10px">
        <label>Pré-visualização do texto</label>
        <textarea id="preview" class="preview" readonly></textarea>
      </div>
      <div class="muted">Dica: se o nome no banco já vier com sufixo (ex.: “César (Auxiliar)”), o sistema ignora e calcula o título correto pela faixa/titularidade.</div>
    </div>
  </div>

<script>
// ===== labelTitle (mesma regra do servidor) =====
function labelTitle(extra){
  const rawFaixa = String(extra.faixa||'');
  const titular = !!(extra.eh_titular || extra.is_titular);
  const norm = s => String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const f = norm(rawFaixa);

  if (titular) return 'Prof. Titular';

  if (/azul/.test(f) || /roxa?/.test(f)) return 'Mon.';
  if (/marrom/.test(f)) return 'Instr.';

  if (/preta/.test(f)) {
    if (/\b(3|3o|3º|4|4o|4º|5|5o|5º|6|6o|6º)\b/.test(f)) return 'Prof.';
    if (/lisa/.test(f) || /\b(1|1o|1º|2|2o|2º)\b/.test(f)) return 'Instr.';
    return 'Instr.';
  }
  if (/vermelha\s*e\s*preta/.test(f) || /\b7\b/.test(f)) return 'M.';
  if (/vermelha\s*e\s*branca/.test(f) || /\b8\b/.test(f)) return 'G.M.';
  if (/vermelha/.test(f) && /\b9\b/.test(f)) return 'G.M.';
  if (/vermelha/.test(f) && /\b10\b/.test(f)) return 'V.M.';

  return 'Colaborador';
}

function byId(id){ return document.getElementById(id); }
function loadSecret(){ const v=localStorage.getItem('kokoro_admin_secret'); if(v) byId('admin-secret').value=v; }
function saveSecret(){ const v=byId('admin-secret').value.trim(); if(v) localStorage.setItem('kokoro_admin_secret', v); }

function buildBody(){
  const body = {
    professor_id: byId('prof-id').value.trim(),
    valor_pago: Number(byId('valor').value||0),
    metodo: byId('metodo').value,
    pago_em: byId('pago-em').value ? new Date(byId('pago-em').value).toISOString() : undefined,
    faixa: byId('faixa').value.trim() || undefined,
    eh_titular: byId('eh-titular').value === 'sim',
  };
  return body;
}

function fmtBRL(n){ return (Number(n)||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'}); }

async function callAPI(path, body, extraHeaders){
  const secret = byId('admin-secret').value.trim();
  if(!secret){ alert('Informe o Admin Secret.'); throw new Error('sem secret'); }
  const resp = await fetch(path, {
    method: 'POST',
    headers: {'Content-Type':'application/json','x-admin-secret': secret, ...(extraHeaders||{})},
    body: JSON.stringify(body)
  });
  const data = await resp.json().catch(()=> ({}));
  if(!resp.ok){ throw new Error(data?.error || ('HTTP '+resp.status)); }
  return data;
}

async function doPreview(){
  const body = buildBody();
  const titulo = labelTitle(body);
  byId('calc-badge').textContent = 'Título: ' + titulo;

  // usa /api/financeiro/recibo (gera texto e retorna JSON)
  const data = await callAPI('/api/financeiro/recibo', body);
  const texto = data?.texto || '(sem texto)';
  byId('preview').value = texto.replace('Colaborador: ', `Colaborador: `); // apenas garante render
}

async function doEmail(){
  const body = buildBody();
  const to = byId('email').value.trim();
  if(!to){ alert('Informe o e-mail de destino.'); return; }
  body.para_email = to;
  const data = await callAPI('/api/financeiro/recibo_email', body);
  byId('preview').value = data?.preview_texto || '(enviado; sem prévia)';
  alert('E-mail enviado ✔');
}

async function doWhats(){
  const body = buildBody();
  const to = byId('whats').value.trim();
  if(!to){ alert('Informe o número WhatsApp destino.'); return; }
  body.destino_whatsapp = to;
  const data = await callAPI('/api/financeiro/recibo_whatsapp', body);
  byId('preview').value = data?.preview_texto || '(enviado; sem prévia)';
  alert('WhatsApp enviado ✔');
}

function limpar(){
  ['prof-id','prof-nome','faixa','valor','pago-em','email','whats'].forEach(id=> byId(id).value='');
  byId('eh-titular').value='nao';
  byId('metodo').value='PIX';
  byId('preview').value='';
  byId('calc-badge').textContent='Título: —';
}

document.addEventListener('DOMContentLoaded', ()=>{
  loadSecret();
  byId('admin-secret').addEventListener('change', saveSecret);
  byId('btn-preview').addEventListener('click', ()=>doPreview().catch(e=>alert(e.message||e)));
  byId('btn-email').addEventListener('click', ()=>doEmail().catch(e=>alert(e.message||e)));
  byId('btn-wa').addEventListener('click', ()=>doWhats().catch(e=>alert(e.message||e)));
  byId('btn-limpar').addEventListener('click', limpar);
});
</script>
</body>
</html>
HTML
echo " - criado: $SRC"

# ========= 2) Adicionar link "Repasses (Colaboradores)" no Financeiro =========
if [ -f "$FIN" ]; then
  cp -f "$FIN" "$FIN.bak.$TS"
  # injeta um botão/link logo abaixo do <h1>Sistema de Controle Financeiro</h1>
  python3 - "$FIN" <<'PY'
import io,sys,re
p=sys.argv[1]
s=io.open(p,'r',encoding='utf-8').read()
btn_html = r'''
    <div class="card" style="display:flex;justify-content:flex-start;gap:10px;align-items:center">
      <a class="btn-back" href="/admin/financeiro/repasses.html">↗ Repasses (Colaboradores)</a>
      <span class="hint">Gerar/Enviar recibos com cálculo automático de título por faixa.</span>
    </div>
'''
s2 = re.sub(r'(<h1>[^<]*Sistema de Controle Financeiro[^<]*</h1>\s*)', r'\1'+btn_html, s, count=1, flags=re.I)
io.open(p,'w',encoding='utf-8').write(s2)
print(" - patch aplicado ao", p)
PY
else
  echo "AVISO: $FIN não encontrado (link não inserido)."
fi

echo "OK. Abra /admin/financeiro/repasses.html no navegador."
echo "Para desfazer: ./$UNDO"
