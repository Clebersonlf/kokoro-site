document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#invite-form');
  if (!form) return;

  const outputBox = document.createElement('div');
  outputBox.id = 'invite-link-box';
  outputBox.style.marginTop = '10px';
  outputBox.style.padding = '10px';
  outputBox.style.background = '#111';
  outputBox.style.border = '1px solid #333';
  outputBox.style.borderRadius = '8px';
  outputBox.style.color = '#0f0';
  outputBox.style.fontSize = '0.9rem';
  form.appendChild(outputBox);

  const submitBtn = form.querySelector('button[type="submit"]');
  submitBtn.addEventListener('click', async (ev) => {
    ev.preventDefault();

    const nome  = form.querySelector('[name="nome"]').value;
    const email = form.querySelector('[name="email"]').value;

    outputBox.innerHTML = "⏳ Gerando link curto...";

    try {
      // Chama a API convites/criar
      const r = await fetch('/api/convites/criar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, email })
      });
[main 1456658] feat(invite): adiciona script para link curto em caixinha
 1 file changed, 62 insertions(+)
 create mode 100644 invite-tokenonly.js
Enumerating objects: 4, done.
Counting objects: 100% (4/4), done.
Delta compression using up to 8 threads
Compressing objects: 100% (3/3), done.
Writing objects: 100% (3/3), 1.23 KiB | 10.00 KiB/s, done.
Total 3 (delta 1), reused 0 (delta 0), pack-reused 0
remote: Resolving deltas: 100% (1/1), completed with 1 local object.
To https://github.com/Clebersonlf/kokoro-site.git
   0db9466..1456658  main -> main
branch 'main' set up to track 'origin/main'.
cleberson@Cleberson:/mnt/c/Users/clebe/Desktop/kokoro-site$
cd /mnt/c/Users/clebe/Desktop/kokoro-site
mkdir -p api/convites
cat > api/convites/criar.js <<'JS'
...código do criar.js...
