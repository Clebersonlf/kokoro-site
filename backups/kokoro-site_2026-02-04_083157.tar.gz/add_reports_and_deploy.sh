#!/usr/bin/env bash
set -euo pipefail

TS="$(date +%Y%m%d_%H%M%S)"
BASE="admin/financeiro"
REL="$BASE/relatorios.html"
FIN="$BASE/financeiro.html"
REP="$BASE/repasses.html"
UNDO="UNDO_add_reports_${TS}.sh"

mkdir -p "$BASE"

# ========= UNDO =========
cat > "$UNDO" <<EOF
#!/usr/bin/env bash
set -euo pipefail
echo ">> Desfazendo 'Relatórios'..."
[ -f "$REL" ] && rm -f "$REL" && echo " - removido: $REL"
if [ -f "$FIN.bak.$TS" ]; then mv -f "$FIN.bak.$TS" "$FIN"; echo " - restaurado: $FIN"; fi
if [ -f "$REP.bak.$TS" ]; then mv -f "$REP.bak.$TS" "$REP"; echo " - restaurado: $REP"; fi
echo "OK: desfazido."
EOF
chmod +x "$UNDO"
echo ">> UNDO criado: ./$UNDO"

# ========= 1) Criar relatorios.html (v1: casca visível; depois plugamos nos dados) =========
cat > "$REL" <<'HTML'
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>KOKORO 心 - Relatórios Financeiros</title>
  <link rel="stylesheet" href="/admin/css/linkbtn.css">
  <link rel="stylesheet" href="/admin/css/btns.css">
  <style>
    :root { --cor-fundo:#121212; --cor-container:#1a1a1a; --cor-borda:#333;
            --cor-texto-principal:#f0f0f0; --cor-azul:#3498db; }
    body{margin:0;background:var(--cor-fundo);color:var(--cor-texto-principal);font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Arial}
    .container{max-width:1600px;margin:0 auto;padding:24px}
    .topbar{display:flex;gap:12px;justify-content:flex-end;padding:10px 16px}
    .btn{border:1px solid #334155;border-radius:.6rem;background:#111827;color:#bfdbfe;text-decoration:none;padding:.55rem .9rem}
    .btn:hover{border-color:#3b82f6;color:#dbeafe}
    h1{color:var(--cor-azul);text-align:center;margin:8px 0 20px}
    .grid{display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(260px,1fr))}
    .card{background:linear-gradient(180deg,#1a1a1a,#171717);border:1px solid var(--cor-borda);border-radius:12px;padding:16px}
    .kpis{display:grid;gap:12px;grid-template-columns:repeat(3,1fr);margin:16px 0}
    .kpi{background:#181818;border:1px solid #2a2a2a;border-radius:10px;padding:14px;text-align:center}
    .kpi h3{margin:2px 0 6px;font-size:.95rem;opacity:.8}
    .kpi p{margin:0;font-weight:800;font-size:1.5rem}
    .toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:8px 0 16px}
    .toolbar input,.toolbar select,.toolbar button{background:#2a2a2a;color:#fff;border:1px solid #3a3a3a;border-radius:8px;padding:10px}
    canvas{width:100%;height:320px;max-height:420px}
    .muted{opacity:.75;font-size:.9rem}
  </style>
</head>
<body>
  <nav class="topbar">
    <a class="btn" href="/admin/financeiro/financeiro.html">← Voltar ao Financeiro</a>
    <a class="btn" href="/admin/index.html">Admin</a>
  </nav>
  <div class="container">
    <h1>Relatórios Financeiros</h1>

    <div class="toolbar">
      <select id="preset">
        <option value="30">Últimos 30 dias</option>
        <option value="90">Últimos 90 dias</option>
        <option value="365" selected>Últimos 12 meses</option>
        <option value="custom">Personalizado…</option>
      </select>
      <input type="date" id="ini" />
      <input type="date" id="fim" />
      <button id="btn-atualizar">Atualizar</button>
      <button id="btn-pdf">Gerar PDF</button>
    </div>

    <div class="kpis">
      <div class="kpi"><h3>Receitas</h3><p id="kpi-receitas">R$ 0,00</p></div>
      <div class="kpi"><h3>Despesas + Repasses</h3><p id="kpi-despesas">R$ 0,00</p></div>
      <div class="kpi"><h3>Saldo</h3><p id="kpi-saldo">R$ 0,00</p></div>
    </div>

    <div class="grid">
      <div class="card"><h3>Receitas vs Despesas (Linha)</h3><canvas id="chartLinha"></canvas></div>
      <div class="card"><h3>Composição de Receita (Pizza)</h3><canvas id="chartPizza"></canvas></div>
      <div class="card"><h3>Receitas por Mês (Barras)</h3><canvas id="chartBarras"></canvas></div>
      <div class="card"><h3>Despesas & Repasses por Mês (Colunas)</h3><canvas id="chartColunas"></canvas></div>
    </div>

    <p class="muted">v1: esta tela já está online. Na próxima etapa, conectaremos estes gráficos diretamente às APIs /api/financeiro para dados 100% do backend.</p>
  </div>

  <!-- Chart.js CDN (leve) -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
  const fmtBR = n => (Number(n)||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});

  // v1: dados de amostra locais (substituiremos por fetch às APIs)
  function dadosMock(){
    const meses = Array.from({length:12},(_,i)=>new Date(new Date().getFullYear(), new Date().getMonth()-11+i, 1))
      .map(d=>d.toLocaleDateString('pt-BR',{month:'short'}));
    const rec = meses.map(()=>Math.round(2000+Math.random()*3500));
    const des = meses.map(()=>Math.round(800+Math.random()*2200));
    const rep = meses.map(()=>Math.round(300+Math.random()*1200));

    const receitas = rec.reduce((a,b)=>a+b,0);
    const despesas = des.reduce((a,b)=>a+b,0) + rep.reduce((a,b)=>a+b,0);
    return { meses, rec, des, rep, receitas, despesas };
  }

  // cria/atualiza gráficos
  let gLinha,gPizza,gBarras,gColunas;
  function render(){
    const { meses, rec, des, rep, receitas, despesas } = dadosMock();
    document.getElementById('kpi-receitas').textContent = fmtBR(receitas);
    document.getElementById('kpi-despesas').textContent = fmtBR(despesas);
    document.getElementById('kpi-saldo').textContent    = fmtBR(receitas-despesas);

    const ctxL = document.getElementById('chartLinha'), ctxP = document.getElementById('chartPizza'),
          ctxB = document.getElementById('chartBarras'), ctxC = document.getElementById('chartColunas');

    [gLinha,gPizza,gBarras,gColunas].forEach(g=>g && g.destroy());

    gLinha = new Chart(ctxL, {
      type:'line',
      data:{ labels:meses, datasets:[
        { label:'Receitas', data:rec },
        { label:'Despesas', data:des.map((v,i)=>v+rep[i]), },
      ]},
      options:{ responsive:true, plugins:{ legend:{ position:'bottom' } } }
    });

    gPizza = new Chart(ctxP, {
      type:'pie',
      data:{ labels:['Mensalidades','Produtos','Serviços'],
             datasets:[{ data:[55,25,20] }] },
      options:{ responsive:true, plugins:{ legend:{ position:'bottom' } } }
    });

    gBarras = new Chart(ctxB, {
      type:'bar',
      data:{ labels:meses, datasets:[{ label:'Receitas', data:rec }] },
      options:{ responsive:true, plugins:{ legend:{ position:'bottom' } } }
    });

    gColunas = new Chart(ctxC, {
      type:'bar',
      data:{ labels:meses, datasets:[
        { label:'Despesas', data:des },
        { label:'Repasses', data:rep }
      ]},
      options:{ responsive:true, plugins:{ legend:{ position:'bottom' } } }
    });
  }

  document.getElementById('btn-atualizar').addEventListener('click', render);
  document.getElementById('btn-pdf').addEventListener('click', () => {
    window.print(); // v1 simples; depois trocamos por jsPDF com imagens dos gráficos
  });

  // presets/intervalo (v1 ainda não filtra dados mock)
  const preset = document.getElementById('preset'), ini = document.getElementById('ini'), fim = document.getElementById('fim');
  function setPreset(){
    const v = preset.value;
    if(v==='custom'){ ini.disabled=false; fim.disabled=false; }
    else{
      ini.disabled=true; fim.disabled=true;
      const dias = Number(v)||365;
      const dFim = new Date(); const dIni = new Date(Date.now()-dias*86400000);
      ini.valueAsDate = dIni; fim.valueAsDate = dFim;
    }
  }
  preset.addEventListener('change', setPreset); setPreset();

  render();
  </script>
</body>
</html>
HTML

echo " - criado/atualizado: $REL"

# ========= 2) Injetar botão '📊 Relatórios' nas páginas topo =========
inject_btn() {
  local FILE="$1"
  [ -f "$FILE" ] || { echo "   (pular) não existe: $FILE"; return; }
  cp -f "$FILE" "$FILE.bak.$TS"

  # Se já existe link, não duplica
  if grep -q 'href="/admin/financeiro/relatorios.html"' "$FILE"; then
    echo "   - já tinha botão em: $FILE"
    return
  fi

  # Insere ANTES de </nav> ou, se não tiver, depois da primeira <nav
  if grep -q '</nav>' "$FILE"; then
    sed -i '0,/<\/nav>/{s#</nav>#  <a class="btn-back" href="/admin/financeiro/relatorios.html">📊 Relatórios</a>\n</nav>#}' "$FILE"
  else
    sed -i '0,/<nav[^>]*>/{s#<nav[^>]*>#&\n  <a class="btn-back" href="/admin/financeiro/relatorios.html">📊 Relatórios</a>#}' "$FILE"
  fi
  echo "   - botão inserido em: $FILE"
}

inject_btn "$FIN" || true
inject_btn "$REP"  || true

# ========= 3) Deploy =========
echo ">> Fazendo deploy (produção)…"
npx vercel@latest --prod

# ========= 4) Teste rápido =========
echo
echo "--- Testando URLs ---"
for URL in \
  "https://www.planckkokoro.com/admin/financeiro/relatorios.html" \
  "https://www.planckkokoro.com/admin/financeiro/financeiro.html" \
  "https://www.planckkokoro.com/admin/financeiro/repasses.html"
do
  echo "URL: $URL"
  curl -sSI "$URL" | sed -n '1,12p'
  echo
done

echo "OK. Se precisar desfazer: ./$UNDO"
