# Kokoro — Diagnóstico do Projeto (20250921_014350)
_Raio-X automático do repositório (infra, forms, APIs, financeiro, graduação, timer)_

## Ambiente
- PWD: /mnt/c/Users/clebe/Desktop/kokoro-site
- OS: Linux Cleberson 6.6.87.2-microsoft-standard-WSL2 #1 SMP PREEMPT_DYNAMIC Thu Jun  5 18:30:46 UTC 2025 x86_64 x86_64 x86_64 GNU/Linux
- Node: v22.19.0
- NPM:  10.9.3
- Vercel CLI: 48.1.0

## Git
- Branch atual: main
- Último commit: 6574757 2025-09-21 01:07:17 -0300 fix: ajustes no timer e ícones admin
- Remotos:
  origin	git@github.com:Clebersonlf/kokoro-site.git (fetch)
  origin	git@github.com:Clebersonlf/kokoro-site.git (push)

### git status (resumo)
 M .idea/workspace.xml
 M diagnose_kokoro.sh
?? _audit_kokoro/scan_20250921_013409/
?? _audit_kokoro/scan_20250921_014350/

## Inventário
- Arquivos (sem node_modules):
  Total de arquivos: 6364

### Extensões & contagem de linhas
