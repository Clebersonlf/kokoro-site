#!/usr/bin/env bash
set -euo pipefail
cp -f "admin/financeiro/relatorios.html.bak.20250916_020817" "admin/financeiro/relatorios.html"
echo "OK: restaurado admin/financeiro/relatorios.html a partir de admin/financeiro/relatorios.html.bak.20250916_020817"
